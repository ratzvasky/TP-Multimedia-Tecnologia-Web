var Gifs = require('./gif');
var GifsService = require('./service');


var service = GifsService(Gifs);


module.exports = service;