var Categorias = require('./categoria');
var CategoriasService = require('./service');


var service = CategoriasService(Categorias);


module.exports = service;